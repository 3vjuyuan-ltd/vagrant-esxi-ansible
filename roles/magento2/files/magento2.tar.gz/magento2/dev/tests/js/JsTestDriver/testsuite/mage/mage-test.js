/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
MageTest = TestCase('MageTest');

MageTest.prototype.setUp = function() {
    /*:DOC += <button id="save"></button>*/
};