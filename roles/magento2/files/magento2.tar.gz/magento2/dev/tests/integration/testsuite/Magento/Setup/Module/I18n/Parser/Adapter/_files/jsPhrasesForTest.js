$t("text double quote");
$t('text single quote');
$t('text "some');
