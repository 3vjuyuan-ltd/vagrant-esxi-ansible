<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Sales\Controller\Adminhtml\Order\Stub;

class OrderCreateStub extends \Magento\Sales\Controller\Adminhtml\Order\Create
{
    public function execute()
    {
        // Empty method stub for test
    }
}
