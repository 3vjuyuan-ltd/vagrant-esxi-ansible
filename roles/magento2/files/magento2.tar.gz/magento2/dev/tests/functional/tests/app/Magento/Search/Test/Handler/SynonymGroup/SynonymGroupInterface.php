<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Search\Test\Handler\SynonymGroup;

use Magento\Mtf\Handler\HandlerInterface;

/**
 * Interface SynonymGroupInterface
 */
interface SynonymGroupInterface extends HandlerInterface
{
    //
}
