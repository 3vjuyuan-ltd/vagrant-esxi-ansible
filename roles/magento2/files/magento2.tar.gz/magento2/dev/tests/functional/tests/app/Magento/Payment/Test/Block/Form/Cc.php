<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Payment\Test\Block\Form;

use Magento\Mtf\Block\Form;

/**
 * Form for filling credit card data.
 */
class Cc extends Form
{
    //
}
