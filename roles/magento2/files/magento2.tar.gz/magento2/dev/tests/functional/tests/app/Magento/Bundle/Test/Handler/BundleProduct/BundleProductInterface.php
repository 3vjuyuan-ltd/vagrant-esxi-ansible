<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Bundle\Test\Handler\BundleProduct;

use Magento\Mtf\Handler\HandlerInterface;

/**
 * Interface BundleProductInterface
 */
interface BundleProductInterface extends HandlerInterface
{
    //
}
