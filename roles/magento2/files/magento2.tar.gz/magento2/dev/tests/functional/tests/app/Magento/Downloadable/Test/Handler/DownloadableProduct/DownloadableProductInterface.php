<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Downloadable\Test\Handler\DownloadableProduct;

use Magento\Mtf\Handler\HandlerInterface;

/**
 * Interface DownloadableProductInterface
 */
interface DownloadableProductInterface extends HandlerInterface
{
    //
}
