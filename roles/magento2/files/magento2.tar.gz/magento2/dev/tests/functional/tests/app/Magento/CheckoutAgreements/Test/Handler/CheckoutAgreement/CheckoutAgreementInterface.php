<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\CheckoutAgreements\Test\Handler\CheckoutAgreement;

use Magento\Mtf\Handler\HandlerInterface;

/**
 * Interface CheckoutAgreementInterface
 */
interface CheckoutAgreementInterface extends HandlerInterface
{
    //
}
