<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\CatalogSearch\Test\Block\Adminhtml\Edit;

use Magento\Mtf\Block\Form as WidgetForm;

/**
 * Form for search term.
 */
class SearchTermForm extends WidgetForm
{
    //
}
