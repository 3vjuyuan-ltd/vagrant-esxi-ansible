<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Cms\Test\Handler\CmsBlock;

use Magento\Mtf\Handler\HandlerInterface;

/**
 * Interface CmsBlockInterface
 */
interface CmsBlockInterface extends HandlerInterface
{
    //
}
