<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\CheckoutAgreements\Test\Block\Adminhtml\Block\Agreement\Edit;

use Magento\Mtf\Block\Form;

/**
 * Class AgreementsForm
 * Form for creation of the term
 */
class AgreementsForm extends Form
{
    //
}
